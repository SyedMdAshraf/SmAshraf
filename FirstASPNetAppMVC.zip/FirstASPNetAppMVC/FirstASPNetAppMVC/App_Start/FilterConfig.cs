﻿using System.Web;
using System.Web.Mvc;
using FirstASPNetAppMVC.Infrastructure;

namespace FirstASPNetAppMVC
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new HandleErrorAttribute());
            filters.Add(new ProfileAllAttribute());//Custom Global Filter-----
        }
    }
}
