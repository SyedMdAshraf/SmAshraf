﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstASPNetAppMVC.Models
{
    [System.ComponentModel.DataAnnotations.MetadataType(typeof(EmployeeMetadata))]
    public partial class Employee
    {



    }
}