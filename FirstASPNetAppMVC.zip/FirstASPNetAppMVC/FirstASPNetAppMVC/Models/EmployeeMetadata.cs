﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FirstASPNetAppMVC.Models
{
    public class EmployeeMetadata
    {
        [Required (ErrorMessage ="ID can not be Empty.")]
        public int Id { get; set; }

        [Required(ErrorMessage ="Name cannot be empty.")]
        [StringLength(20)]
        public string Name { get; set; }

        [Required(ErrorMessage ="Designation cannot be empty.")]
        public int Designation { get; set; }
        [Required(ErrorMessage ="Department cannot be empty.")]
        public int Department { get; set; }


    }
}