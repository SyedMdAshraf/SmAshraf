﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSchedularSystem_Entities
{
    public class FlightEntities
    {
        public string FlightNo { get; set; }

        public string Name { get; set; }

        public string Destination { get; set; }

        public string Terminal { get; set; }

        public int GateNo { get; set; }

        public Dept Departure { get; set; }

        public string Status { get; set; }

    }
    public class Dept
    {
        public DateTime Scheduled { get; set; }

        public DateTime Estimated { get; set; }

        public DateTime Actual { get; set; }
    }
    //public enum Status
    //{
    //    OnTime=1, Delayed, Cancelled, Expected, Arrived,
    //    CheckIn, Boarding, GateClosed, Departed
    //}
}
