﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightSchedularSystem_Entities;
using FlightSchedularSystem_Exception;
using FlightSchedularSystem_DAL;
using System.Text.RegularExpressions;

namespace FlightSchedularSystem_BusinessLayer
{
    public class FlightBL
    {
        FlightDAL flightDAL = new FlightDAL();
        private static bool ValidateFlight(FlightEntities flight)
        {
            StringBuilder sb = new StringBuilder();
            bool validFlight = true;
            //Validations Here
            if(!Regex.IsMatch(flight.FlightNo,@"[A-Z]{2}[-][0-9]{4}"))
            {
                validFlight = false;
                sb.Append(Environment.NewLine+ "Flight Number Should be 7 characters long. With first 2 characters upper case letters followed by hyphen and then 4 digits ");
            }

            if(!(flight.Name=="Air India"|| flight.Name == "Indigo" || flight.Name=="GoAir"))
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Flight Name should be Air India, Indigo or GoAir");
            }

            if(!Regex.IsMatch(flight.Destination,@"[A-Z][a-z]{3,}"))
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Destination should have atleast 3 alphabets starting with Capital letter");
            }

            if(flight.Terminal==string.Empty)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Terminal Required");
            }

            if(flight.GateNo<=0)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Invalid Gate No");
            }

            if (!(flight.Status == "On Time" || flight.Status == "Delayed" || flight.Status == "Cancelled"
                ||flight.Status=="Expected"||flight.Status=="Arrived" || flight.Status == "CheckIn"
                || flight.Status == "Boarding" || flight.Status == "GateClosed" || flight.Status == "Departed"))
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Unknown Status");
            }


            //Add Departure Validation Here

            if (validFlight == false)
                throw new FlightException(sb.ToString());
            return validFlight;
        }

        public static bool AddFlightBL(FlightEntities newFlight)
        {
            bool flightAdded = false;
            try
            {
                if(ValidateFlight(newFlight))
                {
                    FlightDAL flightDAL = new FlightDAL();
                    flightAdded = flightDAL.AddFlightDAL(newFlight);
                }
            }
            catch(FlightException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return flightAdded;
        }

        public static bool UpdateFlightBL(FlightEntities updateFlight)
        {
            bool flightUpdated = false;
            try
            {
                if(ValidateFlight(updateFlight))
                {
                    FlightDAL flightDAL = new FlightDAL();
                    flightUpdated = flightDAL.UpdateFlightDAL(updateFlight);
                }
            }
            catch(FlightException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return flightUpdated;
        }
        public static bool DeleteFlightBL(string deleteFlightNo)
        {
            bool flightDeleted = false;
            try
            {
                if (deleteFlightNo.Length==7)
                {
                    FlightDAL flightDAL = new FlightDAL();
                    flightDeleted = flightDAL.DeleteFlightDAL(deleteFlightNo);
                }
                else
                {
                    throw new FlightException("Invalid Flight No");
                }
            }
            catch (FlightException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return flightDeleted;
        }

        public static FlightEntities SearchFlightBL(string searchFlightNo)
        {
            FlightEntities searchFlight = null;
            try
            {
                FlightDAL flightDAL = new FlightDAL();
                searchFlight = flightDAL.SearchFlightDAL(searchFlightNo);
            }
            catch(FlightException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return searchFlight;
        }

        public static List<FlightEntities> GetAllFlightsBL()
        {
            List<FlightEntities> flightList = null;
            try
            {
                FlightDAL flightDAL = new FlightDAL();
                flightList = flightDAL.GetAllFlightsDAL();
            }
            catch(FlightException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return flightList;
        }



    }
}
