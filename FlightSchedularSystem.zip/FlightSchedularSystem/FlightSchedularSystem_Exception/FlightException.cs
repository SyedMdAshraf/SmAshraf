﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSchedularSystem_Exception
{
    public class FlightException : ApplicationException
    {
        public FlightException()
            :base()
        {
        }

        public FlightException(string message) 
            : base(message)
        {
        }

        public FlightException(string message,Exception innerException)
            : base(message,innerException)
        {
        }
    }
}
